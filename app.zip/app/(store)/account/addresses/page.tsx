'use client';

import { useEffect, useState, type FormEvent } from 'react';
type Address = {
  id: string;
  label: string;
  fullName: string;
  phone: string;
  addressLine1: string;
  addressLine2?: string | null;
  area: string;
  city: string;
  state: string;
  postalCode?: string | null;
  instructions?: string | null;
  isDefault: boolean;
};
type Form = Omit<Address, 'id'>;
const blank: Form = {
  label: 'Home',
  fullName: '',
  phone: '',
  addressLine1: '',
  addressLine2: '',
  area: '',
  city: 'Abeokuta',
  state: 'Ogun',
  postalCode: '',
  instructions: '',
  isDefault: false,
};
export default function AddressesPage() {
  const [items, setItems] = useState<Address[]>([]);
  const [form, setForm] = useState<Form>(blank);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  async function load() {
    const r = await fetch('/api/account/addresses', { cache: 'no-store' });
    const d = await r.json();
    if (r.ok) setItems(d.addresses ?? []);
    else setError(d.error ?? 'Unable to load addresses');
  }
  useEffect(() => {
    void load();
  }, []);
  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError('');
    const response = await fetch(
      editingId ? `/api/account/addresses/${editingId}` : '/api/account/addresses',
      {
        method: editingId ? 'PATCH' : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      },
    );
    const data = await response.json();
    setBusy(false);
    if (!response.ok) {
      setError(data.error ?? 'Unable to save address');
      return;
    }
    setForm(blank);
    setEditingId(null);
    await load();
  }
  function edit(a: Address) {
    setEditingId(a.id);
    setForm({
      label: a.label,
      fullName: a.fullName,
      phone: a.phone,
      addressLine1: a.addressLine1,
      addressLine2: a.addressLine2 ?? '',
      area: a.area,
      city: a.city,
      state: a.state,
      postalCode: a.postalCode ?? '',
      instructions: a.instructions ?? '',
      isDefault: a.isDefault,
    });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
  async function remove(id: string) {
    if (!window.confirm('Delete this saved address?')) return;
    const r = await fetch(`/api/account/addresses/${id}`, { method: 'DELETE' });
    if (r.ok) await load();
    else {
      const d = await r.json();
      setError(d.error ?? 'Unable to delete address');
    }
  }
  const fields: Array<[keyof Form, string, boolean]> = [
    ['label', 'Label (Home / Office / Other)', true],
    ['fullName', 'Recipient name', true],
    ['phone', 'Phone number', true],
    ['addressLine1', 'Street address', true],
    ['addressLine2', 'Apartment / landmark', false],
    ['area', 'Area / neighbourhood', true],
    ['city', 'City', true],
    ['state', 'State', true],
    ['postalCode', 'Postal code', false],
  ];
  return (
    <main className="mx-auto min-h-screen max-w-5xl px-5 py-12 text-[#24231f]">
      <h1 className="text-3xl font-black">Saved delivery addresses</h1>
      <p className="mt-2 text-sm text-stone-600">
        Add Home, Office and other addresses. Select any saved address during checkout.
      </p>
      <form
        onSubmit={submit}
        className="mt-8 grid gap-4 rounded-2xl border border-stone-200 bg-white p-6 sm:grid-cols-2"
      >
        <h2 className="text-lg font-bold sm:col-span-2">
          {editingId ? 'Edit address' : 'Add a new address'}
        </h2>
        {fields.map(([key, label, required]) => (
          <label key={key} className="grid gap-1.5 text-sm font-semibold">
            {label}
            <input
              required={required}
              value={String(form[key] ?? '')}
              onChange={(e) => setForm((v) => ({ ...v, [key]: e.target.value }))}
              className="rounded-lg border border-stone-300 px-3 py-3 font-normal"
            />
          </label>
        ))}
        <label className="grid gap-1.5 text-sm font-semibold sm:col-span-2">
          Delivery instructions
          <textarea
            rows={2}
            value={form.instructions ?? ''}
            onChange={(e) => setForm((v) => ({ ...v, instructions: e.target.value }))}
            className="rounded-lg border border-stone-300 px-3 py-3 font-normal"
          />
        </label>
        <label className="flex items-center gap-2 text-sm sm:col-span-2">
          <input
            type="checkbox"
            checked={form.isDefault}
            onChange={(e) => setForm((v) => ({ ...v, isDefault: e.target.checked }))}
          />{' '}
          Make this my default address
        </label>
        <div className="flex flex-wrap gap-3 sm:col-span-2">
          {error && <p className="w-full text-sm text-red-600">{error}</p>}
          <button
            disabled={busy}
            className="rounded-lg bg-[#9b4c2e] px-5 py-3 font-bold text-white disabled:opacity-50"
          >
            {busy ? 'Saving…' : editingId ? 'Update address' : 'Save address'}
          </button>
          {editingId && (
            <button
              type="button"
              onClick={() => {
                setEditingId(null);
                setForm(blank);
              }}
              className="rounded-lg border px-5 py-3 text-sm font-semibold"
            >
              Cancel edit
            </button>
          )}
        </div>
      </form>
      <section className="mt-8 grid gap-3">
        {items.map((a) => (
          <article
            key={a.id}
            className="flex flex-wrap items-start justify-between gap-4 rounded-xl border border-stone-200 bg-white p-5"
          >
            <div>
              <div className="font-bold">
                {a.label}{' '}
                {a.isDefault && (
                  <span className="ml-2 rounded-full bg-emerald-50 px-2 py-1 text-[10px] text-emerald-700">
                    DEFAULT
                  </span>
                )}
              </div>
              <p className="mt-1 text-sm">
                {a.fullName} · {a.phone}
              </p>
              <p className="text-sm text-stone-500">
                {[a.addressLine1, a.addressLine2, a.area, a.city, a.state]
                  .filter(Boolean)
                  .join(', ')}
              </p>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => edit(a)}
                className="rounded-lg border px-3 py-2 text-sm font-semibold"
              >
                Edit
              </button>
              <button
                onClick={() => void remove(a.id)}
                className="rounded-lg border border-red-200 px-3 py-2 text-sm font-semibold text-red-700"
              >
                Delete
              </button>
            </div>
          </article>
        ))}
      </section>
    </main>
  );
}
