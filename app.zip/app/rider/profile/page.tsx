'use client';
import { useEffect, useState } from 'react';
type Profile = {
  phone: string;
  residentialAddress: string;
  vehicleType: string;
  vehicleColor: string;
  plateNumber: string;
  verificationStatus: string;
  isActive: boolean;
  isAvailable: boolean;
  zones: { zone: { name: string; city: string } }[];
};
export default function RiderProfilePage() {
  const [profile, setProfile] = useState<Profile | null>(null);
  const [error, setError] = useState('');
  useEffect(() => {
    fetch('/api/rider/profile')
      .then(async (r) => {
        const d = await r.json();
        if (r.ok) setProfile(d.profile);
        else setError(d.error ?? 'Unable to load profile');
      })
      .catch(() => setError('Unable to load profile'));
  }, []);
  return (
    <main className="mx-auto max-w-3xl px-5 py-10">
      <h1 className="text-3xl font-bold">Rider profile</h1>
      {error && <p className="mt-4">{error}</p>}
      {profile && (
        <section className="mt-6 grid gap-3 rounded-xl border p-6">
          <p>Phone: {profile.phone}</p>
          <p>Address: {profile.residentialAddress}</p>
          <p>
            Vehicle: {profile.vehicleType} · {profile.vehicleColor} · {profile.plateNumber}
          </p>
          <p>Verification: {profile.verificationStatus}</p>
          <p>Account active: {String(profile.isActive)}</p>
          <p>Available: {String(profile.isAvailable)}</p>
          <p>Zones: {profile.zones.map((z) => `${z.zone.name}, ${z.zone.city}`).join(', ')}</p>
        </section>
      )}
    </main>
  );
}
